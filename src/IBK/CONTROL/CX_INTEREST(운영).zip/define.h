#define GAP_TOP			3
#define GAP_SIDE		3
#define GAP_BOTTOM		3
#define GAP_BLOCK		5
#define GAP_PANEL		4

#define borderH			20
//#define map_Height		247 //306
//#define map_halfHeight	111	// map_halfHeight = (map_Height - borderH) / 2
//#define map_Width		520

#define	HTC				20//35
#define	HGC				18//22

#define MAPWND_WIDTH	537 + 2 * (GAP_SIDE + GAP_PANEL)
#define MAPWND_HEIGHT	244 + GAP_TOP + GAP_BOTTOM + GAP_BLOCK + 2 * GAP_PANEL
#define MAPWND_RECT		CRect(0, 0, MAPWND_WIDTH, MAPWND_HEIGHT)

#define BTN_KOSPI_RECT	CRect(6 + GAP_SIDE, GAP_TOP + GAP_PANEL + 3, 120, 20 + 3 + GAP_TOP)
#define BTN_KOSTAR_RECT CRect(120,  GAP_TOP, 240, 26 + GAP_TOP)

#define INCREASE_WIDTH	6
#define INCREASE_HEIGHT 2

#define BONG_WIDTH		40
#define TABLE_WIDTH		248
#define TOP_HEIGHT		26


#define ROUND_PANEL		1
#define ROUND_CONTENTS	2

#define	clBack	64
#define clBox	65
#define	clText	69
#define	clUp	94
#define	clDown	95

//�ǳ�
#define clPanel	66
#define clPanelLine 165

//contents �ܰ�
#define clContents 181
#define clGuide	26

//grid
#define	clHead	74
#define	clHText	76
#define	clData	68
#define	clLine	93
#define	clFocus	78
#define	clRow1	68
#define	clRow2	77
#define clSel	78

//table
#define clTableHBack	96
#define clTableHText	97
#define clTableLine		75
#define clTableSell		191
#define clTableBuy		41
#define clTableBuy2		42
#define clTableData		69
#define clTableGubn		43
