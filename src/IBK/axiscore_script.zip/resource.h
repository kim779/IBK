//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by axiscore.rc
//
#define IDD_AXISCORE_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       133
#define IDD_DLG_DOWN                    134
#define IDI_ICON2                       136
#define IDC_PROGRESS1                   1000
#define IDC_STATIC_BITMAP               1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
